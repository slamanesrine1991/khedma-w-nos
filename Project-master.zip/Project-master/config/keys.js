module.exports = {
    mongoURI:'mongodb+srv://Zied:01234567@project-pgwxt.mongodb.net/test?retryWrites=true',
    secretOrKey: 'secret'
};